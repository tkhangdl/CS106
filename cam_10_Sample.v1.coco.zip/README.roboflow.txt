
cam_10_Sample - v1 2020-11-03 11:28am
==============================

This dataset was exported via roboflow.ai on November 3, 2020 at 4:29 AM GMT

It includes 730 images.
Kad are annotated in COCO format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


